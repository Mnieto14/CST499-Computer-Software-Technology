<!DOCTYPE html>
<html lang="en"><head><title>Footer Employee Portal</title>
<link href="/dashboard/stylesheets/normalize.css" rel="stylesheet" type="text/css">
<link href="/dashboard/stylesheets/all.css" rel="stylesheet" type="text/css">
<link href="//cdnjs.cloudflare.com/ajax/libs/font-awesome/3.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>
<body>
<footer>
</footer><div class="row">
<div class="large-12 columns">
<div class="row">
<div class="large-8 columns">
<ul class="social">
<li class="twitter"><a href="https://twitter.com">Follow us on Twitter</a></li>
<li class="facebook"><a href="https://www.facebook.com">Like us on Facebook</a></li>
<li class="google"><a href="https://plus.google.com/+xampp/posts">Add us to your G+ Circles</a></li>
</ul>
<ul class="inline-list">
</ul>
</div>
<div class="large-4 columns">
<p class="text-right"><br>
</p>
</div>
</div>
</div>
</div>
</body></html>